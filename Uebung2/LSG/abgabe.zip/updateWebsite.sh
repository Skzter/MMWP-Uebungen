#!/bin/bash

cd $HOME/MMWP-Uebungen/Uebung2/LSG

cp -v "index.html" /home/vgoetze1/public_html/Portfolio
cp -v "index.css" /home/vgoetze1/public_html/Portfolio
cp -v -r pictures /home/vgoetze1/public_html/Portfolio

